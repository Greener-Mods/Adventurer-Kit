INSTALLATION 
                 
This kit has been created and tested with BGEE and BG2EE. 
This is a WEIDU mod thus currently is compatible with other mods.

	1 - Extract the contents of the zip file into your override folder

	2 - Run WeiDU and install

ADVENTURER KIT DESCRIPTION

ADVENTURER: A jack-of-all-trades, master of none, an adventurer uses their broad knowledge base and diverse skillset to create their own luck. Often preferred by many adventuring parties, because they know the value of trust and cooperation and are much less likely to steal from or betray their own companions.

Advantages:
- Luck (+1 to all rolls)

Disadvantages:
- No backstab multiplier

FUTURE  CHANGES  

COPYRIGHT

It can be used by anyone, at any time, anywhere at your own risk

THANK YOU to all that have assisted along the way